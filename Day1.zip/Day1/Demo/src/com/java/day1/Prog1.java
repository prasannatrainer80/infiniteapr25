package com.java.day1;

public class Prog1 {

	public static void main(String[] args) {
		int x=12;
		double y=12.5;
		String str="Infinite";
		System.out.println("X value is " +x);
		System.out.println("Y value is  " +y);
		System.out.println("Name is " +str);
	}
}
